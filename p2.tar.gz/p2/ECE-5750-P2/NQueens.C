#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// typedef struct {
//     int    pos[2];
//     queue_ *next;
// } queue_;

// int NQueens(int n)
// {
//     queue_ q;
//     queue = [];
//     max_val = 0;
//     // Initialize the queue
//     for(int i = 0; i < n ; i++)
//     {
//         queue.push([(0,i)]);
//     }
//     while(queue.size()>0)
//     {
//         Node = queue.pop();
//         int j = Node.size();
//         if(j == n)
//             max_val = max(max_val,score(Node));
//         else
//         {
//             for(int i = 0; i < n ;  i++)
//             {
//                 if(check(Node,(j,i)))
//                     queue.push(Node.append((j,i)));
//             }
//         }
//     };
//     return max_score;
// }

int main(int argc, char **argv)
{
    int N = atoi(argv[1]);
    int P = atoi(argv[2]);
    printf("%i %i \n",N,P);
}