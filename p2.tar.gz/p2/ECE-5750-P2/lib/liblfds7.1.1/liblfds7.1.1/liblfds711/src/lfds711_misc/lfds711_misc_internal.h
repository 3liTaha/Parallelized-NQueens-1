/***** the library wide include file *****/
#include "../liblfds711_internal.h"

/***** private prototypes *****/
void lfds711_misc_prng_internal_big_slow_high_quality_init( int long long unsigned seed );
