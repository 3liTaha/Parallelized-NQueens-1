/***** includes *****/
#include "libbenchmark_results_internal.h"





/****************************************************************************/
#pragma warning( disable : 4100 )

void libbenchmark_results_cleanup( struct libbenchmark_results_state *rs )
{
  LFDS711_PAL_ASSERT( rs != NULL );

  return;
}

#pragma warning( default : 4100 )

