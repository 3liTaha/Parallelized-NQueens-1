/***** includes *****/
#include "libbenchmark_benchmarkset_internal.h"





/****************************************************************************/
#pragma warning( disable : 4100 )

void libbenchmark_benchmarkset_cleanup( struct libbenchmark_benchmarkset_state *bsets )
{
  LFDS711_PAL_ASSERT( bsets != NULL );

  return;
}

#pragma warning( default : 4100 )

