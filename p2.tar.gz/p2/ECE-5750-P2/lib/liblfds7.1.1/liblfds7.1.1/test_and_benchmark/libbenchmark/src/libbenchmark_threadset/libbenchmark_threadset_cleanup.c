/***** includes *****/
#include "libbenchmark_threadset_internal.h"





/****************************************************************************/
#pragma warning( disable : 4100 )

void libbenchmark_threadset_cleanup( struct libbenchmark_threadset_state *pts )
{
  LFDS711_PAL_ASSERT( pts != NULL );

  // TRD : we do naaauuuuthin'

  return;
}

#pragma warning( default : 4100 )

