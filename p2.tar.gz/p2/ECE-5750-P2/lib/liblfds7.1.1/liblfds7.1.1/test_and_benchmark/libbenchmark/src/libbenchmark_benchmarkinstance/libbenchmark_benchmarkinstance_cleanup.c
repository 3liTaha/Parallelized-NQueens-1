/***** includes *****/
#include "libbenchmark_benchmarkinstance_internal.h"





/****************************************************************************/
#pragma warning( disable : 4100 )

void libbenchmark_benchmarkinstance_cleanup( struct libbenchmark_benchmarkinstance_state *bs )
{
  LFDS711_PAL_ASSERT( bs != NULL );

  // TRD : we do naaauuuutttthhiiiinnnn'

  return;
}

#pragma warning( default : 4100 )

