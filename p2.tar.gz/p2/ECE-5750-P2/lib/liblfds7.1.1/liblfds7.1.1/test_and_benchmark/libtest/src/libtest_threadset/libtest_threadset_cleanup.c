/***** includes *****/
#include "libtest_threadset_internal.h"





/****************************************************************************/
#pragma warning( disable : 4100 )

void libtest_threadset_cleanup( struct libtest_threadset_state *ts )
{
  LFDS711_PAL_ASSERT( ts != NULL );

  // TRD : we do naaauuuuthin'

  return;
}

#pragma warning( default : 4100 )

