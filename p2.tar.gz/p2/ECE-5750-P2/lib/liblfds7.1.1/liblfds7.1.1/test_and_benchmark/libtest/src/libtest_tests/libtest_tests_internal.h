/***** the library wide include file *****/
#include "../libtest_internal.h"

/***** defines *****/
#define TEST_DURATION_IN_SECONDS  5
#define TIME_LOOP_COUNT           10000
#define REDUCED_TIME_LOOP_COUNT   1000

/***** private prototypes *****/

