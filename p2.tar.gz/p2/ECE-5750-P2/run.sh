#!/bin/bash 
#PBS -k eo 
#PBS -m abe  
#PBS -M amt297@cornell.edu 
#PBS -N first job 
./blocking