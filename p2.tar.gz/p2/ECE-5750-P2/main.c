#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <pthread.h>
#include <sched.h>
#include <errno.h>
#include <unistd.h>
#include <stdint.h>
#include <math.h>
#define BILLION 1000000000L
#ifdef __MACH__
# include <mach/mach_time.h>
#endif

#include "queue.h"
#include "stddev.h"

#ifdef __MACH__
unsigned long long gettime()
{
	return mach_absolute_time();
}
#else
unsigned long long gettime()
{
	struct timespec t;
	clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &t);
	return (long long)t.tv_sec * 1000000000LL + t.tv_nsec;
}
#endif

static void *malloc_aligned(unsigned int size)
{
	void *ptr;
	int r = posix_memalign(&ptr, 256, size);
	if (r != 0) {
		perror("malloc error");
		abort();
	}
	memset(ptr, 0, size);
	return ptr;
}

struct thread_data {
	pthread_t thread_id;
	struct queue_root *queue;
	double locks_ps;
	unsigned long long rounds;
};

// static unsigned long long threshold = 10000;

// static void *thread_entry_point(void *_thread_data)
// {
// 	unsigned long long counter = 0;
// 	unsigned long long t0, t1;
// 	struct thread_data *td = (struct thread_data *)_thread_data;
// 	struct queue_root *queue = td->queue;

// 	struct queue_head *item = 
// 		malloc_aligned(sizeof(struct queue_head));
// 	INIT_QUEUE_HEAD(item);

// 	t0 = gettime();
// 	while (1) {
// 		queue_put(item, queue);
// 		item = queue_get(queue);
// 		if (!item) {
// 			abort();
// 		}
// 		counter ++;
// 		if (counter != threshold) {
// 			continue;
// 		} else {
// 			t1 = gettime();
// 			unsigned long long delta = t1 - t0;
// 			double locks_ps = (double)counter / ((double)delta / 1000000000LL);
// 			td->locks_ps = locks_ps;
// 			td->rounds += 1;
// 			t0 = t1;
// 			counter = 0;

// 			#if 0
// 			printf("thread=%16lx round done in %.3fms, locks per sec=%.3f\n",
// 			       (long)pthread_self(),
// 			       (double)delta / 1000000,
// 			       locks_ps);
// 			#endif
// 		}
// 	}

// 	return NULL;
// }
int cnt = 0;
void NQueens(int n)
{
    struct queue_root *queue = ALLOC_QUEUE_ROOT();
    int x = 13;
    for(int i = x; i < x+1 ; i++)
    {
        struct queue_head *item = malloc_aligned(sizeof(struct queue_head));
		INIT_QUEUE_HEAD(item,1);
        item->positions[0] = i;
        queue_put(item, queue);
        while( item != NULL)
        {
            int j = item->n;
            if(j == n)
            {
                // printf("[");
                // for(int i = 0; i < n ; i++)
                // {
                //     printf("(%i, %i)",i,item->positions[i]);
                // }
                // printf("]\n");
                cnt++;
            }
            else
            {
                for(int i = 0; i < n ;  i++)
                {
                    int x = 1;
                    for(int k = 0 ; k < j ; k++)
                    {
                        if(item->positions[k] == i || k - item->positions[k] == j - i || k + item->positions[k] == j + i)
                            x=0;
                    }
                    if(x)
                    {
                        struct queue_head *item_new = malloc_aligned(sizeof(struct queue_head));
                        for(int q = 0; q < j ; q++)
                            item_new->positions[q]=item->positions[q];
                        item_new->positions[j]=i;
                        item_new->n=j+1;
                        queue_put(item_new, queue);
                    }   
                }
            }
            item = queue_get(queue);
        }
    }
    struct queue_head * item = queue_get(queue);

    printf("\n");
}

int main(int argc, char **argv)
{

	// struct queue_root *queue = ALLOC_QUEUE_ROOT();

	// for (int i=0; i < 10; i++) {
	// 	struct queue_head *item = 
	// 		malloc_aligned(sizeof(struct queue_head));
	// 	INIT_QUEUE_HEAD(item,i);
	// 	queue_put(item, queue);
	// }


	// for (int i = 0 ; i < 12; i++) {
    //     struct queue_head *item = queue_get(queue);
    //     if(item!=NULL)
    //         printf("%i \n",item->n);
    //     else
    //         printf("failed\n");
	// }
    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start);
    NQueens(15);
    clock_gettime(CLOCK_MONOTONIC, &end);
    double time = BILLION *(end.tv_sec - start.tv_sec) +(end.tv_nsec - start.tv_nsec);
    time = time / BILLION;
    printf("Elapsed time: %lf seconds\n", time);
    printf("%i\n",cnt);
	return 0;
}